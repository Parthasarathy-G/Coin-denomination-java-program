import java.util.*;

public class Main {
    static int[] coin = {1000,500,200,100,50,20, 10, 5, 2, 1};

    public static String soln(int n) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < coin.length; i++) {
            int count = n / coin[i];
            for (int j = 0; j < count; j++) {
                result.append(coin[i]).append(" ");
            }
            n %= coin[i];
        }
        return result.toString();
    }

    public static void main(String[] args) {
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = ps.nextInt();
            int k = a[i];
            System.out.println(soln(k));
        }
    }
}